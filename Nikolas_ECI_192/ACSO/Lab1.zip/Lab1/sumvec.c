#include<stdio.h>

int main(void)
{
	int vec[10],i;
	for(i=0;i<10;i++)
	{
		printf("Ingrese valor %d:\n",i+1);
		scanf("%d",&vec[i]);
	}
	int a=0;
	for(i=0;i<10;i++)
	{
		a+=vec[i];
	}
	printf("La suma de los elementos del vector es: %d\n",a);
	printf("El vector es:\n");
	for(i=0;i<10;i++)
	{
		printf("%d ",vec[i]);
	}
	printf("\n");
}
