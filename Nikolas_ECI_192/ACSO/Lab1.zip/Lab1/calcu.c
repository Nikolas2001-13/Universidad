#include <stdio.h>

int suma();
int resta();
int multiplicacion();
float division();
int main(void)
{
	int operacion;
	printf("¿Que operacion quieres hacer?\n");
	printf("1.Suma\n");
	printf("2.Resta\n");
	printf("3.Multiplicacion\n");
	printf("4.Division\n");
	printf("Digite el numero de la operacion:\n");
	scanf("%d",&operacion);

	if (operacion==1)
	{
		int n1,n2;
		printf("Dame el primer numero: ");
		scanf("%d",&n1);
		printf("Dame el segundo numero: ");
		scanf("%d",&n2);
		printf("La suma es: %d\n",suma(n1,n2));
	}
	else if(operacion==2)
	{
		int n1,n2;
		printf("Dame el primer numero: ");
		scanf("%d",&n1);
		printf("Dame el segundo numero: ");
		scanf("%d",&n2);
		printf("La resta es: %d\n",resta(n1,n2));
	}
	else if (operacion==3)
	{
		int n1,n2;
		printf("Dame el primer numero: ");
		scanf("%d",&n1);
		printf("Dame el segundo numero: ");
		scanf("%d",&n2);
		printf("La multiplicacion es: %d\n",multiplicacion(n1,n2));
	}
	else if(operacion==4)
	{
		int n1,n2;
		printf("Dame el primer numero: ");
		scanf("%d",&n1);
		printf("Dame el segundo numero: ");
		scanf("%d",&n2);
		if (n2==0)
		{
			printf("No se puede dividir por 0\n");
		}
		else
		{
			printf("La division es:%.2f\n",division(n1,n2));
		}
	}
}
int suma(int n1,int n2)
{
	int suma;
	suma=n1+n2;
	return suma;
}
int resta(int n1,int n2)
{
	int resta;
	resta=n1-n2;
	return resta;
}
int multiplicacion(int n1, int n2)
{
	int multiplicacion;
	multiplicacion=n1*n2;
	return multiplicacion;
}
float division (n1,n2)
{
	float division;
	division= (float)n1 / (float)n2;
	return division;
}
