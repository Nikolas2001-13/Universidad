#include <stdio.h>

int main(void)
{
	int n1,n2;
	printf("Dame el primer numero: ");
	scanf("%d",&n1);
	printf("Dame el segundo numero: ");
	scanf("%d",&n2);
	if (n1<n2)
	{
		printf("El mayor es: %d\n",n2);
	}
	else
	{
		printf("El mayor es: %d\n",n1);
	}
}
