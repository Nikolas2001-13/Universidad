
#include <stdio.h>

int main(void){
	int n1,n2,s;
	printf("Numero 1: ");
	scanf("%d",&n1);
	printf("Numero 2: ");
	scanf("%d",&n2);
	s=n1+n2;
	printf("La suma es: %d\n",s);
}
