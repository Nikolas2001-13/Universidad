#include<stdio.h>

int main(void)
{
	int vec[10],i;
	for(i=0;i<10;i++)
	{
		printf("Ingrese valor %d:\n",i+1);
		scanf("%d",&vec[i]);
	}
	int min=vec[0];
	for(i=0;i<10;i++)
	{
		if (vec[i]<=min)
		{
			min=vec[i];
		}
	}
	printf("El valor minimo del vector es: %d\n",min);
}
